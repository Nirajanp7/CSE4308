#Nirajan Pokharel 1002068164

import sys
import math

# Define move orderings
STANDARD_MOVES = [("red", 2), ("blue", 2), ("red", 1), ("blue", 1)]
MISERE_MOVES = list(reversed(STANDARD_MOVES))

# Evaluate terminal state score
def terminal_score(red, blue, version):
    score = red * 2 + blue * 3
    return -score if version == "standard" else score

def is_terminal(red, blue):
    return red == 0 or blue == 0

# Evaluation function for depth-limited search 
def evaluate(red, blue, maximizing, version):
    score = red * 2 + blue * 3
    return score if maximizing else -score

def get_possible_moves(red, blue, version):
    moves = STANDARD_MOVES if version == "standard" else MISERE_MOVES
    valid_moves = []
    for color, count in moves:
        if color == "red" and red >= count:
            valid_moves.append((color, count))
        elif color == "blue" and blue >= count:
            valid_moves.append((color, count))
    return valid_moves

def apply_move(red, blue, move):
    color, count = move
    if color == "red":
        return red - count, blue
    else:
        return red, blue - count

# Minimax with alpha-beta pruning
def minimax(red, blue, depth, alpha, beta, maximizing, version, limit=None):
    if is_terminal(red, blue):
        return terminal_score(red, blue, version), None
    if limit is not None and depth >= limit:
        return evaluate(red, blue, maximizing, version), None

    best_move = None
    if maximizing:
        max_eval = -math.inf
        for move in get_possible_moves(red, blue, version):
            new_r, new_b = apply_move(red, blue, move)
            eval_score, _ = minimax(new_r, new_b, depth + 1, alpha, beta, False, version, limit)
            if eval_score > max_eval:
                max_eval = eval_score
                best_move = move
            alpha = max(alpha, eval_score)
            if beta <= alpha:
                break
        return max_eval, best_move
    else:
        min_eval = math.inf
        for move in get_possible_moves(red, blue, version):
            new_r, new_b = apply_move(red, blue, move)
            eval_score, _ = minimax(new_r, new_b, depth + 1, alpha, beta, True, version, limit)
            if eval_score < min_eval:
                min_eval = eval_score
                best_move = move
            beta = min(beta, eval_score)
            if beta <= alpha:
                break
        return min_eval, best_move

def human_turn(red, blue):
    while True:
        move = input(f"Your move (e.g., 'red 1' or 'blue 2'): ").strip().lower().split()
        if len(move) != 2:
            print(" Invalid input. Please type both color and number. Format: red 1 or blue 2.")
            continue
        color, count_str = move
        if color not in ["red", "blue"] or count_str not in ["1", "2"]:
            print(" Invalid move. Only 'red' or 'blue' and values 1 or 2 allowed.")
            continue
        count = int(count_str)
        if color == "red" and red >= count:
            return apply_move(red, blue, (color, count))
        elif color == "blue" and blue >= count:
            return apply_move(red, blue, (color, count))
        else:
            print(" Not enough marbles in that pile. Try again.")

def print_state(red, blue):
    print(f"Current State => Red: {red}, Blue: {blue}")

def play_game(red, blue, version="standard", first="computer", depth=None):
    turn = first
    while True:
        if is_terminal(red, blue):
            print_state(red, blue)
            score = terminal_score(red, blue, version)
            if (version == "standard" and turn == "computer") or (version == "misere" and turn == "human"):
                print(f"Computer wins! Score: {score}")
            else:
                print(f"Human wins! Score: {score}")
            break

        print_state(red, blue)
        if turn == "computer":
            _, move = minimax(red, blue, 0, -math.inf, math.inf, True, version, depth)
            print(f"Computer chooses: {move[0]} {move[1]}")
            red, blue = apply_move(red, blue, move)
            turn = "human"
        else:
            try:
                red, blue = human_turn(red, blue)
            except KeyboardInterrupt:
                print("\nGame interrupted by user. Exiting.")
                sys.exit(0)
            turn = "computer"

if __name__ == "__main__":
    args = sys.argv[1:]
    if len(args) < 2:
        print("Usage: red_blue_nim.py <num-red> <num-blue> <version> <first-player> <depth>")
        sys.exit(1)

    red = int(args[0])
    blue = int(args[1])
    version = args[2] if len(args) > 2 else "standard"
    first = args[3] if len(args) > 3 else "computer"
    try:
        depth = int(args[4]) if len(args) > 4 else None
    except ValueError:
        print("Invalid depth value. It should be an integer.")
        sys.exit(1)

    play_game(red, blue, version, first, depth)
