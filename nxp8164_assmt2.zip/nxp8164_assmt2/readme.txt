Name: Nirajan Pokharel  
UTA ID: 1002068164  

Programming Language: Python 3.12.2

Code Structure:

 red_blue_nim.py : Contains the full implementation of the red-blue nim game.
  Uses Minimax algorithm with Alpha-Beta pruning.
  Supports both standard and misere versions.
  Supports optional depth-limited Minimax for extra credit.

Running Instructions:

To run the game:

 python red_blue_nim.py <num-red> <num-blue> <version> <first-player> <depth>

- <num-red> and <num-blue> : integers (e.g., 3 4)
- <version> (optional): 'standard' or 'misere' (default: standard)
- <first-player> (optional): 'computer' or 'human' (default: computer)
- <depth> (optional): Depth limit for Minimax search (only for extra credit)

Examples:
a python red_blue_nim.py 3 3  
b python red_blue_nim.py 4 4 misere human  
c python red_blue_nim.py 5 5 standard computer 4  

No compilation required.

ACS Omega Compatibility:
Yes, this code runs on ACS Omega with Python 3.

