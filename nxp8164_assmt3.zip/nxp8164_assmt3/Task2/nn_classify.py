import sys
import numpy as np
from collections import Counter

def load_data(file_path):
    data = []
    with open(file_path, 'r') as f:
        for line in f:
            if line.strip():
                parts = list(map(float, line.strip().split()))
                data.append((parts[:-1], parts[-1]))
    return data

def euclidean_distance(a, b):
    return np.sqrt(np.sum((np.array(a) - np.array(b))**2))

def predict_class(neighbors):
    count = Counter(neighbors)
    max_votes = max(count.values())
    candidates = [label for label, votes in count.items() if votes == max_votes]
    return np.random.choice(candidates), candidates

def classify(train_file, test_file, k=1):
    train = load_data(train_file)
    test = load_data(test_file)

    results = []
    total_accuracy = 0

    for idx, (test_x, true_y) in enumerate(test):
        distances = [(train_y, euclidean_distance(test_x, train_x)) for train_x, train_y in train]
        distances.sort(key=lambda x: x[1])
        top_k = [label for label, _ in distances[:k]]

        pred_y, tied_classes = predict_class(top_k)

        if len(tied_classes) == 1:
            acc = 1.0 if pred_y == true_y else 0.0
        else:
            acc = 1.0 / len(tied_classes) if true_y in tied_classes else 0.0

        results.append(f"objID = {idx} predicted class = {int(pred_y)} true class = {int(true_y)} accuracy = {acc}")
        total_accuracy += acc

    with open("result.txt", "w") as f:
        for line in results:
            f.write(line + "\n")

    print(f"Overall classification accuracy: {total_accuracy / len(test):.5f}")

if __name__ == "__main__":
    if len(sys.argv) < 3:
        print("Usage: python nn_classify.py <training-file> <test-file> [<k>]")
        sys.exit(1)

    train_file = sys.argv[1]
    test_file = sys.argv[2]
    k = int(sys.argv[3]) if len(sys.argv) > 3 else 1

    classify(train_file, test_file, k)
