Name: Nirajan Pokharel
UTA ID: 1002068164
Language: Python 3.10

How to run:
-------------
1. Open terminal and navigate to the task2 folder.
2. Example usage with k=3:
   python3 nn_classify.py pendigits_training_adj.txt pendigits_test_adj.txt 3

3. If k is not provided, it defaults to 1:
   python3 nn_classify.py yeast_training.txt yeast_test.txt

This will:
- Print overall accuracy to the terminal.
- Save detailed predictions and accuracy to result.txt.
