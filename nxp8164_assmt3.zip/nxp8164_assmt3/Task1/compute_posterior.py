import sys

# Define hypotheses with priors and candy distributions
hypotheses = {
    'h1': {'prior': 0.1, 'C': 1.0,  'L': 0.0},
    'h2': {'prior': 0.2, 'C': 0.75, 'L': 0.25},
    'h3': {'prior': 0.4, 'C': 0.5,  'L': 0.5},
    'h4': {'prior': 0.2, 'C': 0.25, 'L': 0.75},
    'h5': {'prior': 0.1, 'C': 0.0,  'L': 1.0},
}

def normalize(dist):
    total = sum(dist.values())
    return {k: v / total for k, v in dist.items()}

def predict_next(obs_probs):
    p_c = sum(obs_probs[h] * hypotheses[h]['C'] for h in hypotheses)
    p_l = sum(obs_probs[h] * hypotheses[h]['L'] for h in hypotheses)
    return round(p_c, 5), round(p_l, 5)

def format_prob(value):
    return f"{value:.5f}"

def main():
    obs_seq = sys.argv[1] if len(sys.argv) > 1 else ""
    output = []

    # Initial priors
    probs = {h: hypotheses[h]['prior'] for h in hypotheses}

    output.append(f"Observation sequence Q: {obs_seq}")
    output.append(f"Length of Q: {len(obs_seq)}\n")
    
    output.append("Before Observations :")
    for h in ['h1', 'h2', 'h3', 'h4', 'h5']:
        output.append(f"P({h}) = {format_prob(hypotheses[h]['prior'])}")
    
    p_c, p_l = predict_next(probs)
    output.append(f"\nProbability that the next candy we pick will be C, given Q: {format_prob(p_c)}")
    output.append(f"Probability that the next candy we pick will be L, given Q: {format_prob(p_l)}\n")

    for idx, obs in enumerate(obs_seq):
        # Bayes update
        for h in probs:
            probs[h] *= hypotheses[h][obs]
        probs = normalize(probs)

        output.append(f"After Observation {idx + 1} = {obs}:\n")
        for h in ['h1', 'h2', 'h3', 'h4', 'h5']:
            output.append(f"P({h} | Q) = {format_prob(probs[h])}")
        p_c, p_l = predict_next(probs)
        output.append(f"\nProbability that the next candy we pick will be C, given Q: {format_prob(p_c)}")
        output.append(f"Probability that the next candy we pick will be L, given Q: {format_prob(p_l)}\n")

    with open("result.txt", "w") as f:
        f.write("\n".join(output))

if __name__ == "__main__":
    main()
