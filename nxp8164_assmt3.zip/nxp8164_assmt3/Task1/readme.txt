Name: Nirajan Pokharel
UTA ID: 1002068164
Language: Python 3.10

How to run:

 Open terminal.
 Navigate to the folder: `cd task1`
 Run the script with your observation string:
 python3 compute_posterior.py CCLLLLLLCCCC

This will generate a file `result.txt` in the same folder, with all posterior probabilities and predictions formatted exactly like the sample output.
