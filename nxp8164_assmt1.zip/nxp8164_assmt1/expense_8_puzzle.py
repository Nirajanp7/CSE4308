#NIRAJAN POKHAREL 1002068164



import sys
import heapq
import datetime
from collections import deque


class PuzzleState:
    """
    Represents a single state of the puzzle.
    board: 3x3 list of lists with integers (0 indicates blank)
    parent: the predecessor PuzzleState
    move: description of the move taken to reach this state
    depth: depth in the search tree
    cost: path cost so far (sum of tile costs)
    zero_pos: (row, col) of the blank tile
    """
    def __init__(self, board, parent=None, move=None, depth=0, cost=0):
        self.board = [list(row) for row in board]
        self.parent = parent
        self.move = move  
        self.depth = depth
        self.cost = cost
        self.zero_pos = self.find_zero()

    def find_zero(self):
        for i, row in enumerate(self.board):
            for j, val in enumerate(row):
                if val == 0:
                    return (i, j)
        return None

    def get_neighbors(self):
        """
        Generate neighboring states by moving the blank tile.
        The cost of a move is the tile we move, i.e. if we move tile 6, cost=6.
        """
        neighbors = []
        row, col = self.zero_pos
        moves = [(-1, 0, "Up"), (1, 0, "Down"), (0, -1, "Left"), (0, 1, "Right")]

        for dr, dc, direction in moves:
            new_row, new_col = row + dr, col + dc
            if 0 <= new_row < 3 and 0 <= new_col < 3:
                new_board = [list(r) for r in self.board]
                new_board[row][col], new_board[new_row][new_col] = new_board[new_row][new_col], new_board[row][col]

                move_cost = new_board[row][col]

                neighbor_state = PuzzleState(
                    new_board,
                    parent=self,
                    move=f"Move {move_cost} {direction}",
                    depth=self.depth + 1,
                    cost=self.cost + move_cost
                )
                neighbors.append(neighbor_state)
        return neighbors

    def __eq__(self, other):
        if not isinstance(other, PuzzleState):
            return False
        return self.board == other.board

    def __hash__(self):
        return hash(tuple(tuple(row) for row in self.board))

    def __lt__(self, other):
        return self.cost < other.cost

# Utility functions


def write_to_dump(dump_file, content):
    """Writes debug/tracing output to dump_file if it is not None."""
    if dump_file:
        with open(dump_file, "a") as f:
            f.write(content + "\n")


def trace_solution(state):
    """Collect the moves from the initial state to this state by following parents."""
    path = []
    while state.parent is not None:
        path.append(state.move)
        state = state.parent
    path.reverse()
    return path

# Heuristic function for Greedy and A*

def heuristic(board, goal):
    """
    An admissible heuristic for the puzzle. We'll do a modified Manhattan distance:
    For each tile, compute Manhattan distance * the tile's value (since moving tile 'v' costs 'v').
    """
    goal_positions = {}
    for r in range(3):
        for c in range(3):
            goal_positions[goal[r][c]] = (r, c)

    distance = 0
    for r in range(3):
        for c in range(3):
            val = board[r][c]
            if val != 0:
                goal_r, goal_c = goal_positions[val]
                dist = abs(r - goal_r) + abs(c - goal_c)
                distance += dist * val
    return distance


# BFS

def bfs(start, goal, dump_file):
    start_state = PuzzleState(start)
    frontier = deque([start_state])
    explored = set()

    nodes_popped = 0
    nodes_expanded = 0
    nodes_generated = 1
    max_fringe_size = 1

    while frontier:
        max_fringe_size = max(max_fringe_size, len(frontier))
        current = frontier.popleft()
        nodes_popped += 1

        # Dump the current status
        frontier_boards = [s.board for s in frontier]
        explored_boards = [s.board for s in explored]
        write_to_dump(dump_file, f"Popped: {current.board}")
        write_to_dump(dump_file, f"Frontier: {frontier_boards}")
        write_to_dump(dump_file, f"Explored: {explored_boards}\n")

        # Check goal
        if current.board == goal:
            return (nodes_popped, nodes_expanded, nodes_generated, max_fringe_size,
                    current.depth, current.cost, trace_solution(current))

        if current not in explored:
            explored.add(current)
            nodes_expanded += 1

            neighbors = current.get_neighbors()
            for neighbor in neighbors:
                if neighbor not in explored:
                    frontier.append(neighbor)
                    nodes_generated += 1

    return None


# DFS


def dfs(start, goal, dump_file):
    start_state = PuzzleState(start)
    stack = [start_state]
    explored = set()

    nodes_popped = 0
    nodes_expanded = 0
    nodes_generated = 1
    max_fringe_size = 1

    while stack:
        max_fringe_size = max(max_fringe_size, len(stack))
        current = stack.pop()
        nodes_popped += 1

        frontier_boards = [s.board for s in stack]
        explored_boards = [s.board for s in explored]
        write_to_dump(dump_file, f"Popped: {current.board}")
        write_to_dump(dump_file, f"Frontier: {frontier_boards}")
        write_to_dump(dump_file, f"Explored: {explored_boards}\n")

        if current.board == goal:
            return (nodes_popped, nodes_expanded, nodes_generated, max_fringe_size,
                    current.depth, current.cost, trace_solution(current))

        if current not in explored:
            explored.add(current)
            nodes_expanded += 1

            neighbors = current.get_neighbors()
            for neighbor in neighbors:
                if neighbor not in explored:
                    stack.append(neighbor)
                    nodes_generated += 1

    return None


# Depth-Limited Search (DLS)


def dls_recursive(state, goal, limit, dump_file, explored_stats):
    if state.board == goal:
        return state
    if limit == 0:
        return None

    explored_stats["expanded"] += 1

    neighbors = state.get_neighbors()
    for neighbor in neighbors:
        explored_stats["generated"] += 1
        explored_stats["popped"] += 1
        if explored_stats["popped"] > explored_stats["max_fringe"]:
            explored_stats["max_fringe"] = explored_stats["popped"]

        # Dump
        write_to_dump(dump_file, f"DLS visiting depth {neighbor.depth}: {neighbor.board}")

        result = dls_recursive(neighbor, goal, limit-1, dump_file, explored_stats)
        if result is not None:
            return result
    return None


def dls(start, goal, limit, dump_file):
    start_state = PuzzleState(start)
    explored_stats = {"popped": 1, "expanded": 0, "generated": 1, "max_fringe": 1}

    result = dls_recursive(start_state, goal, limit, dump_file, explored_stats)

    if result is not None:
        # We have a solution
        return (explored_stats["popped"],
                explored_stats["expanded"],
                explored_stats["generated"],
                explored_stats["max_fringe"],
                result.depth,
                result.cost,
                trace_solution(result))
    else:
        return None


# Iterative Deepening Search (IDS)


def ids(start, goal, dump_file):
    """
    Iterative deepening search: repeatedly call DLS with increasing depth.
    We'll artificially cap it at something like 50.
    """
    max_depth = 50
    for limit in range(max_depth + 1):
        write_to_dump(dump_file, f"IDS iteration with depth limit = {limit}")
        result = dls(start, goal, limit, dump_file)
        if result is not None:
            return result
    return None


# Uniform Cost Search (UCS)


def ucs(start, goal, dump_file):
    start_state = PuzzleState(start)
    frontier = []  # we'll use a heap
    heapq.heappush(frontier, (start_state.cost, start_state))
    explored = set()

    nodes_popped = 0
    nodes_expanded = 0
    nodes_generated = 1
    max_fringe_size = 1

    while frontier:
        max_fringe_size = max(max_fringe_size, len(frontier))
        current_cost, current = heapq.heappop(frontier)
        nodes_popped += 1

        # Dump
        frontier_boards = [s[1].board for s in frontier]
        explored_boards = [s.board for s in explored]
        write_to_dump(dump_file, f"Popped: {current.board} with cost {current_cost}")
        write_to_dump(dump_file, f"Frontier: {frontier_boards}")
        write_to_dump(dump_file, f"Explored: {explored_boards}\n")

        if current.board == goal:
            return (nodes_popped, nodes_expanded, nodes_generated, max_fringe_size,
                    current.depth, current.cost, trace_solution(current))

        if current not in explored:
            explored.add(current)
            nodes_expanded += 1

            for neighbor in current.get_neighbors():
                if neighbor not in explored:
                    nodes_generated += 1
                    heapq.heappush(frontier, (neighbor.cost, neighbor))

    return None


# Greedy Search


def greedy(start, goal, dump_file):
    start_state = PuzzleState(start)

    frontier = []
    # priority = heuristic only
    start_h = heuristic(start, goal)
    heapq.heappush(frontier, (start_h, start_state))

    explored = set()

    nodes_popped = 0
    nodes_expanded = 0
    nodes_generated = 1
    max_fringe_size = 1

    while frontier:
        max_fringe_size = max(max_fringe_size, len(frontier))
        _, current = heapq.heappop(frontier)
        nodes_popped += 1

        frontier_boards = [s[1].board for s in frontier]
        explored_boards = [s.board for s in explored]
        write_to_dump(dump_file, f"Popped: {current.board}")
        write_to_dump(dump_file, f"Frontier: {frontier_boards}")
        write_to_dump(dump_file, f"Explored: {explored_boards}\n")

        if current.board == goal:
            return (nodes_popped, nodes_expanded, nodes_generated, max_fringe_size,
                    current.depth, current.cost, trace_solution(current))

        if current not in explored:
            explored.add(current)
            nodes_expanded += 1

            for neighbor in current.get_neighbors():
                if neighbor not in explored:
                    nodes_generated += 1
                    h = heuristic(neighbor.board, goal)
                    heapq.heappush(frontier, (h, neighbor))

    return None

# A* Search


def a_star(start, goal, dump_file):
    start_state = PuzzleState(start)

    # For A*, priority = cost + heuristic
    start_h = heuristic(start, goal)
    start_priority = start_h + start_state.cost

    frontier = []
    heapq.heappush(frontier, (start_priority, start_state))

    explored = set()

    nodes_popped = 0
    nodes_expanded = 0
    nodes_generated = 1
    max_fringe_size = 1

    while frontier:
        max_fringe_size = max(max_fringe_size, len(frontier))
        current_priority, current = heapq.heappop(frontier)
        nodes_popped += 1

        frontier_boards = [s[1].board for s in frontier]
        explored_boards = [s.board for s in explored]
        write_to_dump(dump_file, f"Popped: {current.board} with priority {current_priority}")
        write_to_dump(dump_file, f"Frontier: {frontier_boards}")
        write_to_dump(dump_file, f"Explored: {explored_boards}\n")

        if current.board == goal:
            return (nodes_popped, nodes_expanded, nodes_generated, max_fringe_size,
                    current.depth, current.cost, trace_solution(current))

        if current not in explored:
            explored.add(current)
            nodes_expanded += 1

            for neighbor in current.get_neighbors():
                if neighbor not in explored:
                    nodes_generated += 1
                    f = neighbor.cost + heuristic(neighbor.board, goal)
                    heapq.heappush(frontier, (f, neighbor))

    return None


# Search Algorithm Dispatcher


def search_algorithm(start, goal, method, dump_file):
    if method == "bfs":
        return bfs(start, goal, dump_file)
    elif method == "ucs":
        return ucs(start, goal, dump_file)
    elif method == "dfs":
        return dfs(start, goal, dump_file)
    elif method == "dls":
        depth_limit = int(input("Enter Depth Limit: "))
        return dls(start, goal, depth_limit, dump_file)
    elif method == "ids":
        return ids(start, goal, dump_file)
    elif method == "greedy":
        return greedy(start, goal, dump_file)
    elif method == "a*":
        return a_star(start, goal, dump_file)
    else:
        print("Invalid search method.")
        return None


# read_board and main


def read_board(file_path):
    board = []
    with open(file_path, "r") as f:
        for line in f:
            line = line.strip()
            if line == "END OF FILE" or not line:
                break
            row_vals = list(map(int, line.split()))
            board.append(row_vals)
    return board


def main():
    if len(sys.argv) < 4:
        print("Usage: expense_8_puzzle.py <start-file> <goal-file> <method> [<dump-flag>]")
        return

    start_file = sys.argv[1]
    goal_file = sys.argv[2]
    method = sys.argv[3].lower()

    dump_flag = sys.argv[4] if len(sys.argv) > 4 else "false"
    dump_file = None
    if dump_flag.lower() == "true":
        # Create a timestamped trace file
        dump_file = f"trace-{datetime.datetime.now().strftime('%Y%m%d-%H%M%S')}.txt"

    start_board = read_board(start_file)
    goal_board = read_board(goal_file)

    result = search_algorithm(start_board, goal_board, method, dump_file)

    if result:
        nodes_popped, nodes_expanded, nodes_generated, max_fringe_size, depth, cost, steps = result
        print(f"Nodes Popped: {nodes_popped}")
        print(f"Nodes Expanded: {nodes_expanded}")
        print(f"Nodes Generated: {nodes_generated}")
        print(f"Max Fringe Size: {max_fringe_size}")
        print(f"Solution Found at depth {depth} with cost of {cost}.")
        print("Steps:")
        for step in steps:
            print(f"\t{step}")
    else:
        print("No solution found.")

if __name__ == "__main__":
    main()
