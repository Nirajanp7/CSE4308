Name: Nirajan Pokharel  
UTA ID: 1002068164  

Programming Language: Python  
Version: Python 3.12  

Code Structure:
- expense_8_puzzle.py: Contains the implementation of the 8-puzzle solver using multiple search algorithms.
- The script reads input files (`start.txt` and `goal.txt`) which represent the initial and goal states.
- Implements various search algorithms, including:
  - Breadth-First Search (BFS)
  - Depth-First Search (DFS)
  - Uniform Cost Search (UCS)
  - Iterative Deepening Search (IDS)
  - Depth-Limited Search (DLS)
  - Greedy Best-First Search
  - A* Search (A-star)

How to Run:

Run the script using the following command:

python3 expense_8_puzzle.py start.txt goal.txt "method" "dump-flag"
where 
 `method`: Choose from `bfs`, `dfs`, `ucs`, `ids`, `dls`, `greedy`, `a*`  
 `dump-flag`: Optional. Use `true` to generate a debug trace file.

Example:

for a*
python3 expense_8_puzzle.py start.txt goal.txt "a*" true

